# Minimal pygame window setup for Mankala
import pygame
import sys

pygame.init()

# Set up the display
WIDTH, HEIGHT = 900, 400
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Mankala')
piecesFont = pygame.font.SysFont(None, 36)
board = {'h1':0,'p1':4,'p2':4,'p3':4,'p4':4,'p5':4,'p6':4,'p7':4,'p8':4,'p9':4,'p10':4,'p11':4,'p12':4,'h2':0}
pit_positions = {
    'p6': (200, 150),
    'p5': (300, 150),
    'p4': (400, 150),
    'p3': (500, 150),
    'p2': (600, 150),
    'p1': (700, 150),
    'p7': (200, 250),
    'p8': (300, 250),
    'p9': (400, 250),
    'p10': (500, 250),
    'p11': (600, 250),
    'p12': (700, 250)
}
pit_radius = 35


def draw_board(surface):
    pit_radius = 35
	# Draw the board outline (rounded rectangle)
    board_rect = pygame.Rect(50, 75, 800, 250)
    pygame.draw.rect(surface, (139, 69, 19), board_rect, border_radius=40)
    pygame.draw.rect(surface, (222, 184, 135), board_rect.inflate(-10, -10), border_radius=35)

    font = piecesFont
    labelFont = pygame.font.SysFont(None, 20)  # smaller font for pit number labels
	# Draw six top pits (circle)
    x = 200
    firstRow = [6,5,4,3,2,1]
    for place in firstRow:
        pit_center = (x, 150)
		#pit_radius = 35
        pygame.draw.circle(surface, (205, 133, 63), pit_center, pit_radius)
        pygame.draw.circle(surface, (255, 248, 220), pit_center, pit_radius - 5)
        # Draw number of pieces for 'p1' in the first top pit
        pieces_text = font.render(str(board[f'p{place}']), True, (0, 0, 0))
        text_rect = pieces_text.get_rect(center=pit_center)
        surface.blit(pieces_text, text_rect)
        # Draw small pit number label just below the top row pit
        label = labelFont.render(str(place), True, (80, 40, 0))
        surface.blit(label, label.get_rect(center=(x, 193)))
        x = x + 100

    x = 200
    secondRow=[7,8,9,10,11,12]
    for place in secondRow:
        pit_center = (x, 250)
        pit_radius = 35
        pygame.draw.circle(surface, (205, 133, 63), pit_center, pit_radius)
        pygame.draw.circle(surface, (255, 248, 220), pit_center, pit_radius - 5)
        # Correctly reference p7-p12 for the bottom row
        pieces_text = font.render(str(board[f'p{place}']), True, (0, 0, 0))
        text_rect = pieces_text.get_rect(center=pit_center)
        surface.blit(pieces_text, text_rect)
        # Draw small pit number label just above the bottom row pit
        label = labelFont.render(str(place), True, (80, 40, 0))
        surface.blit(label, label.get_rect(center=(x, 207)))
        x = x + 100

    # Left store (Player 2)
    left_store_rect = pygame.Rect(75, 120, 75, 160)
    pygame.draw.ellipse(surface, (205, 133, 63), left_store_rect)
    pygame.draw.ellipse(surface, (255, 248, 220), left_store_rect.inflate(-10, -10))
    pieces_text = font.render(str(board['h1']), True, (0, 0, 0))
    text_rect = pieces_text.get_rect(center=(75+(75/2),120+(160/2)))
    surface.blit(pieces_text, text_rect)

    # Right store (Player 1)
    right_store_rect = pygame.Rect(750, 120, 75, 160)
    pygame.draw.ellipse(surface, (205, 133, 63), right_store_rect)
    pygame.draw.ellipse(surface, (255, 248, 220), right_store_rect.inflate(-10, -10))
    pieces_text = font.render(str(board['h2']), True, (0, 0, 0))
    text_rect = pieces_text.get_rect(center=(750+(75/2),120+(160/2)))
    surface.blit(pieces_text, text_rect)

    # Player labels
    p1_label = font.render("Player 1", True, (0, 0, 0))
    surface.blit(p1_label, p1_label.get_rect(center=(450, 100)))
    p2_label = font.render("Player 2", True, (0, 0, 0))
    surface.blit(p2_label, p2_label.get_rect(center=(450, 310)))

currPlayer = 'p1'

def switch_player():
	global currPlayer
	if currPlayer == 'p1':
		currPlayer = 'p2'
	else:
		currPlayer = 'p1'
          
def check_win():
    p1Sum = sum(board[f'p{i}'] for i in range(1, 7))
    p2Sum = sum(board[f'p{i}'] for i in range(7, 13))
    if p1Sum == 0 or p2Sum == 0:
        return True
    else:
        return False
         

message = ""
msgFont = pygame.font.SysFont(None, 30)
game_over = False

# --- Animation state variables ---
# anim_active: True while a move is being animated; blocks new clicks until done
anim_active = False
# anim_numPieces: how many pieces are still waiting to be placed
anim_numPieces = 0
# anim_pitNum: the pit number where the NEXT piece will go
anim_pitNum = 0
# anim_player: which player made the move (stored so we don't lose it mid-animation)
anim_player = None
# anim_last_time: pygame timestamp (ms) of when the last piece was placed
anim_last_time = 0
# anim_highlight: key of the pit most recently updated, drawn with a yellow ring
anim_highlight = None
# anim_just_stored: True for one frame after depositing in a store, so the
# pit at the same counter position (p7 after h1) still gets its piece next frame
anim_just_stored = False
ANIM_DELAY = 600

running = True

# Main Loop
while running:
    for event in pygame.event.get():
        # Block new moves while an animation is in progress
        if event.type == pygame.MOUSEBUTTONDOWN and not game_over and not anim_active:

            mouse_pos = event.pos

            # Check if a top row pit was clicked
            for pit, center in pit_positions.items():
                dx = mouse_pos[0] - center[0]
                dy = mouse_pos[1] - center[1]
                if dx*dx + dy*dy <= pit_radius*pit_radius:                    
                    # Here you would trigger your move logic
                    numPieces = board[pit]

                    pitNum = int(pit[1:])
                    if currPlayer == "p1" and pitNum > 6 or currPlayer == "p2" and pitNum < 7:
                        message = "That's the other player's row! Click again."
                        break

                    message = ""
                    # Empty the source pit immediately so the board shows it's been selected
                    board[pit] = 0
                    # Set up the animation - the while loop is now driven frame by frame
                    anim_numPieces = numPieces
                    anim_pitNum = pitNum + 1    # start placing from the next pit
                    anim_player = currPlayer    # remember whose move this is
                    anim_last_time = pygame.time.get_ticks()  # start the delay timer
                    anim_highlight = pit        # highlight the emptied source pit first
                    anim_active = True          # tell the main loop to run the animation
                    anim_just_stored = False    # reset store flag for new move
                    # This break avoids multiple clicks
                    break

        if event.type == pygame.QUIT:
            running = False

    # --- Frame-by-frame animation step ---
    # This block runs every frame. If a move is animating, it places one piece
    # per ANIM_DELAY ms, replicating one iteration of the original while loop.
    if anim_active:
        now = pygame.time.get_ticks()
        # Only advance if enough time has passed since the last piece was placed
        if now - anim_last_time >= ANIM_DELAY:
            if anim_pitNum == 13 and anim_player == "p2":
                # p2's turn: position 13 is their store (h2) - place here and wrap
                board['h2'] += 1
                anim_highlight = 'h2'
                anim_pitNum = 1          # wrap around to pit 1
                anim_numPieces -= 1
            elif anim_pitNum == 13:
                # p1's turn: skip position 13 (opponent's store), just wrap - no piece placed
                anim_pitNum = 1
                anim_last_time = now     # reset timer but don't place a piece this frame
            elif anim_pitNum == 7 and anim_player == "p1" and not anim_just_stored:
                # p1's turn: deposit in store h1; pitNum stays at 7 so p7 is hit next frame
                board["h1"] += 1
                anim_highlight = 'h1'
                anim_numPieces -= 1
                anim_just_stored = True  # next frame: skip store check, place in p7
            # Place a piece in the current numbered pit (if any pieces remain)
            elif anim_numPieces > 0:
                board[f'p{anim_pitNum}'] += 1
                anim_highlight = f'p{anim_pitNum}'
                anim_numPieces -= 1
                anim_pitNum += 1
                anim_just_stored = False  # clear the flag after placing in the pit
            anim_last_time = now          # reset timer for the next step

            # All pieces have been placed - finish the move
            if anim_numPieces == 0:
                anim_active = False

                # --- YOUR CAPTURE LOGIC GOES HERE ---
                # anim_highlight is always the correct last destination ('p1'-'p12', 'h1', or 'h2')
                last_pit_key = anim_highlight

                # Only compute an opposite pit when last piece landed in a numbered pit
                if last_pit_key and last_pit_key not in ('h1', 'h2'):
                    last_pit_num = int(last_pit_key[1:])
                    opposite_pit_num = 13 - last_pit_num
                    opposite_pit_key = f'p{opposite_pit_num}'
                else:
                    last_pit_num = None
                    opposite_pit_key = None

                print(f"last pit key: {last_pit_key} Last pit value: {board[last_pit_key]}")

                try:
                    if board[last_pit_key] == 1 and board[opposite_pit_key] > 0:
                        message = f"Capture! You just took {board[opposite_pit_key]} pieces from pit {opposite_pit_key[1:]}."
                        board[last_pit_key] = board[opposite_pit_key] + 1
                        board[opposite_pit_key] = 0
                except:
                    pass

                # Check if the last piece landed in this player's store (go again)
                # Use anim_highlight which always holds the exact last destination
                p1_go_again = (anim_highlight == 'h1' and currPlayer == 'p1')
                p2_go_again = (anim_highlight == 'h2' and currPlayer == 'p2')
                if p1_go_again or p2_go_again:
                    player_name = "Player 1" if currPlayer == "p1" else "Player 2"
                    message = f"Go again, {player_name}!"
                else:
                    switch_player()
                # Check if the game is now over
                if not game_over and check_win():
                    if board['h1'] > board['h2']:
                        message = f"Player 1 won with a score of {board['h1']} to {board['h2']}!"
                    else:
                        message = f"Player 2 won with a score of {board['h2']} to {board['h1']}!"
                    game_over = True
                anim_highlight = None     # clear the highlight when the move is complete

    window.fill((245, 222, 179))  # Light brown background
    draw_board(window)
    # Draw a yellow ring around the most recently updated pit to show the animation
    if anim_highlight:
        if anim_highlight in pit_positions:
            # Regular pit - draw a ring around the circle
            hx, hy = pit_positions[anim_highlight]
            pygame.draw.circle(window, (255, 220, 0), (hx, hy), pit_radius + 6, 4)
        elif anim_highlight == 'h1':
            # Left store highlight
            pygame.draw.ellipse(window, (255, 220, 0), pygame.Rect(70, 115, 85, 170), 4)
        elif anim_highlight == 'h2':
            # Right store highlight
            pygame.draw.ellipse(window, (255, 220, 0), pygame.Rect(745, 115, 85, 170), 4)
    turn_text = "Player 1's Turn" if currPlayer == "p1" else "Player 2's Turn"
    turn_surf = msgFont.render(turn_text, True, (0, 0, 139))
    window.blit(turn_surf, turn_surf.get_rect(center=(WIDTH // 2, 40)))
    if message:
        msg_surf = msgFont.render(message, True, (180, 0, 0))
        msg_rect = msg_surf.get_rect(center=(WIDTH // 2, 370))
        window.blit(msg_surf, msg_rect)
    pygame.display.flip()

pygame.quit()
sys.exit()
